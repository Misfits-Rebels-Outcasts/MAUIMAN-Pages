﻿namespace progressbar;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
		//progressBar.Progress = 0.2;
	}
	
	async void OnButtonClicked(object sender, EventArgs args)
	{
		//Console.WriteLine(progressBar.Progress);
		await progressBar.ProgressTo(0.75, 500, Easing.Linear);
	}


}

