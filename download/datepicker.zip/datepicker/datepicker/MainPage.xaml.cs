﻿using System.Globalization;

namespace datepicker;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

	void OnDateSelected(object sender, DateChangedEventArgs args)
	{
		//Console.WriteLine($"Current culture: {CultureInfo.CurrentCulture.Name}");
		Console.WriteLine(((DatePicker)sender).Date);
		Console.WriteLine(((DatePicker)sender).Date.ToString("d"));
		Console.WriteLine(((DatePicker)sender).Date.ToString("D"));
		Console.WriteLine(((DatePicker)sender).Date.ToString("f"));
		Console.WriteLine(((DatePicker)sender).Date.ToString("F"));

		CultureInfo culture = new CultureInfo("en-SG");
		Console.WriteLine(((DatePicker)sender).Date.ToString("d", culture));
		culture = CultureInfo.InvariantCulture;
		Console.WriteLine(((DatePicker)sender).Date.ToString("d", culture));
	}
}

