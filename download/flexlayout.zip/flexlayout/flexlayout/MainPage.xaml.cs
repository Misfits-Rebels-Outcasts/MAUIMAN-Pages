﻿using System.Collections.ObjectModel;

namespace flexlayout;

public partial class MainPage : ContentPage
{
    public MainPage()
	{
		InitializeComponent();
    }

}

