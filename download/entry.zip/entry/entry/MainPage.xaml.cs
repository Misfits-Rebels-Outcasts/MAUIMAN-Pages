﻿namespace entry;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}
    void OnTextChanged(object sender, EventArgs e)
    {
        var text = ((Entry)sender).Text;
        Console.WriteLine(text);
    }
}

