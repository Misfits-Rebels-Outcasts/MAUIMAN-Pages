﻿namespace MauiShop;
using MauiShop.Model;
public partial class MainPage : ContentPage
{
	public Product MyProduct { get; set; }
	public MainPage()
	{
		InitializeComponent();

		MyProduct = new Product
		{
			Id = 1,
			Description = "Apple, Malus domestica, is one of the most widely cultivated tree fruits with a fleshy and edible surrounding tissue.",
			ImageUrl = "https://mauiman.dev/mauishopimages/red-apple-isolated.jpg",
			OfferEndDate = new DateTime(2025, 2, 10),
			ProductName = "Apple",
			Price = 2.80
		};

		this.BindingContext = MyProduct;
		/*
		ProductImage.Source = MyProduct.ImageUrl;
		ProductName.Text = MyProduct.ProductName;
		ProductPrice.Text = MyProduct.Price.ToString();
		ProductDescription.Text = MyProduct.Description;
		ProductOfferEndDate.Date = MyProduct.OfferEndDate;
		*/
	}

	private async void SaveProductButton_OnClicked(object sender, EventArgs e)
	{
		/*
		MyProduct.ImageUrl = ProductImage.Source.ToString();		 
		MyProduct.ProductName = ProductName.Text;
		MyProduct.Price = double.Parse(ProductPrice.Text);
		MyProduct.Description = ProductDescription.Text;
		MyProduct.OfferEndDate = ProductOfferEndDate.Date;
		*/

		await DisplayAlert("Success", "Product saved", "Done");
	}
}

