﻿using System.ComponentModel;
namespace timepicker;
public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
    void OnTimeChanged(object sender, PropertyChangedEventArgs args)
    {
        System.Diagnostics.Debug.WriteLine(timePicker.Time);
    }
}

