﻿namespace stepper;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}
    void OnStepperValueChanged(object sender, ValueChangedEventArgs e)
    {
        stepperLabel.Text = e.NewValue.ToString();
    }

}

