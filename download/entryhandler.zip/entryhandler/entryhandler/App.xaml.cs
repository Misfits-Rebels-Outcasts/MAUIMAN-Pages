﻿
using Microsoft.Maui.Platform;
namespace entryhandler;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();
        
        Microsoft.Maui.Handlers.EntryHandler.EntryMapper.AppendToMapping(nameof(IView.Background), (handler, view) =>
        {
            if (view is MyEntry)
            {

#if ANDROID
                handler.NativeView.SetBackgroundColor(Colors.LightGray.ToNative());
#elif IOS
                  handler.NativeView.BackgroundColor = Colors.LightGray.ToNative();
                  handler.NativeView.BorderStyle = UIKit.UITextBorderStyle.Line;
#elif WINDOWS
                  handler.NativeView.Background = Colors.LightGray.ToNative();
#endif

            }
        });
        
        MainPage = new MainPage();
	}
}
