﻿namespace webview;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
		//webView.Source = "https://mauiman.dev";
		//webView.Source = "index.html";

	}
	async void OnButtonClicked(object sender, EventArgs args)
	{
#if WINDOWS
        var stream = await Microsoft.Maui.Essentials.FileSystem.OpenAppPackageFileAsync("Assets\Resources\Assets\index.html");
#elif ANDROID
		/*
		string fileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "index.html");
		bool doesExist = File.Exists(fileName);
		string text = File.ReadAllText(fileName);
		var stream = await Microsoft.Maui.Essentials.FileSystem.OpenAppPackageFileAsync("index.html");
		*/
		Console.WriteLine("1:" + File.Exists("index.html"));
		Console.WriteLine("2:" + File.Exists("Resources\\Raw\\index.html"));
		Console.WriteLine("3:" + File.Exists("Resources/Raw/index.html"));
		Console.WriteLine("4:" + File.Exists("Resources\\Assets\\index.html"));
		Console.WriteLine("5:" + File.Exists("Resources/Assets/index.html"));
		Console.WriteLine("6:" + File.Exists("Resources\\Assets\\Raw\\index.html"));
		Console.WriteLine("7:" + File.Exists("Resources/Assets/Raw/index.html"));

#endif
	}
}

