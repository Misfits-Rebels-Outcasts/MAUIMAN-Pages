﻿namespace editor;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
	//TextChanged="OnTextChanged" 
	void OnTextChanged(object sender, EventArgs e)
	{
		var text = ((Editor)sender).Text;
		Console.WriteLine(text);
	}
	void OnTextCompleted(object sender, EventArgs e)
	{
		var text = ((Editor)sender).Text;
		Console.WriteLine(text);
	}

}

