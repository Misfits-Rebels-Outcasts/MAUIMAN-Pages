﻿namespace button;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

	 void OnButtonClicked(object sender, EventArgs args)
	{
		label.Text = "Hello from mauiman";
		//await label.Text = "Hello from mauiman";
	}
}

