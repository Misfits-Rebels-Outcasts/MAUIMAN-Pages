﻿using System.Collections.ObjectModel;

namespace collectionview;


public partial class MainPage : ContentPage
{
    public class Fruit
    {
        public string FruitName { get; set; }
        public string FruitDescription { get; set; }

    }

    ObservableCollection<Fruit> fruits = new ObservableCollection<Fruit>();
    public ObservableCollection<Fruit> Fruits { get { return fruits; } }

    public Fruit firstFruit = new Fruit() { FruitName = "Apple 1", FruitDescription = "An apple is an edible fruit produced by an apple tree (Malus domestica)." }; 
    public MainPage()
	{
		InitializeComponent();


        //fruits.Add(new Fruit() { FruitName = "Apple 1", FruitDescription = "An apple is an edible fruit produced by an apple tree (Malus domestica)." });
        fruits.Add(firstFruit);
        fruits.Add(new Fruit() { FruitName = "Orange 1", FruitDescription = "The orange is the fruit of various citrus species in the family Rutaceae." });
        fruits.Add(new Fruit() { FruitName = "Banana 1", FruitDescription = "A long curved fruit with soft pulpy flesh and yellow skin when ripe." });
        fruits.Add(new Fruit() { FruitName = "Grape 1", FruitDescription = "A berry growing in clusters on a grapevine, eaten as fruit and used in making wine." });
        fruits.Add(new Fruit() { FruitName = "Mango 1", FruitDescription = "A mango is an edible stone fruit produced by the tropical tree Mangifera indica." });

        fruits.Add(new Fruit() { FruitName = "Apple 2", FruitDescription = "An apple is an edible fruit produced by an apple tree (Malus domestica)." });
        fruits.Add(new Fruit() { FruitName = "Orange 2", FruitDescription = "The orange is the fruit of various citrus species in the family Rutaceae." });
        fruits.Add(new Fruit() { FruitName = "Banana 2", FruitDescription = "A long curved fruit with soft pulpy flesh and yellow skin when ripe." });
        fruits.Add(new Fruit() { FruitName = "Grape 2", FruitDescription = "A berry growing in clusters on a grapevine, eaten as fruit and used in making wine." });
        fruits.Add(new Fruit() { FruitName = "Mango 2", FruitDescription = "A mango is an edible stone fruit produced by the tropical tree Mangifera indica." });

        fruits.Add(new Fruit() { FruitName = "Apple 3", FruitDescription = "An apple is an edible fruit produced by an apple tree (Malus domestica)." });
        fruits.Add(new Fruit() { FruitName = "Orange 3", FruitDescription = "The orange is the fruit of various citrus species in the family Rutaceae." });
        fruits.Add(new Fruit() { FruitName = "Banana 3", FruitDescription = "A long curved fruit with soft pulpy flesh and yellow skin when ripe." });
        fruits.Add(new Fruit() { FruitName = "Grape 3", FruitDescription = "A berry growing in clusters on a grapevine, eaten as fruit and used in making wine." });
        fruits.Add(new Fruit() { FruitName = "Mango 3", FruitDescription = "A mango is an edible stone fruit produced by the tropical tree Mangifera indica." });

        collectionView.ItemsSource = fruits;
    }
    private void ButtonClickedIndex(object sender, EventArgs e)
    {
        collectionView.ScrollTo(14);
    }
    private void ButtonClickedItem(object sender, EventArgs e)
    {
        collectionView.ScrollTo(firstFruit);
    }

}

