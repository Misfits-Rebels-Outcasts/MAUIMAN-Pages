﻿namespace MauiShop;
using MauiShop.Model;
public partial class MainPage : ContentPage
{
	public Product MyProduct { get; set; }
	public List<Product> MyProducts { get; set; }
	public static ProductViewModel ProductViewModel { get; set; } = new ProductViewModel();
	public MainPage()
	{
		InitializeComponent();

		this.BindingContext = ProductViewModel.Product;

	}

	private void SaveProductButton_OnClicked(object sender, EventArgs e)
	{
		Console.WriteLine("Save Command");
	}
}

