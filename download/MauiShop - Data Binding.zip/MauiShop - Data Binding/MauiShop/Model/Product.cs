﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MauiShop.Model
{

    public class Product : INotifyPropertyChanged
    {
        private int id;
        private string productName;
        private string description;
        private double price;
        private string imageUrl;
        private DateTime offerEndDate;

        public int Id
        {
            get => id;
            set
            {
                id = value;
                RaisePropertyChanged(nameof(Id));

            }
        }

        public string ProductName
        {
            get => productName;
            set
            {
                productName = value;
                RaisePropertyChanged(nameof(ProductName));
            }
        }

        public string Description
        {
            get => description;
            set
            {
                description = value;
                RaisePropertyChanged(nameof(Description));
            }
        }

        public double Price
        {
            get => price;
            set
            {
                price = value;
                RaisePropertyChanged(nameof(Price));
            }
        }

        public string ImageUrl
        {
            get => imageUrl;
            set
            {
                imageUrl = value;
                RaisePropertyChanged(nameof(ImageUrl));
            }
        }

        public DateTime OfferEndDate
        {
            get => offerEndDate;
            set
            {
                offerEndDate = value;
                RaisePropertyChanged(nameof(OfferEndDate));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
