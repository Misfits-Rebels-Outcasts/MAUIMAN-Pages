﻿namespace checkbox;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

	void OnCheckedChanged(object sender, CheckedChangedEventArgs e)
	{
		Console.WriteLine("OnCheckedChanged");
	}
}

