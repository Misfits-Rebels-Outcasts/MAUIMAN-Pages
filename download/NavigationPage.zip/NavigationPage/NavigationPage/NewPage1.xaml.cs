using System;
using Microsoft.Maui;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Xaml;

namespace NavigationPage
{
	public partial class NewPage1 : ContentPage
	{
		public NewPage1()
		{
			InitializeComponent();
			
		}
	}
}