﻿namespace imagebutton;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

    void OnImageButtonClicked(object sender, EventArgs e)
    {
        imageButton.Text = "Hello ImageButton";
    }
}

